public interface Calc{
    
    public int calcular();
}